package com.codegnan.service;

import java.util.Base64;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class ImageDescriptionService {

    private final ChatClient chatClient;

    public ImageDescriptionService(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }

    public String describeImage(MultipartFile file) {

        try {
            byte[] imageBytes = file.getBytes();
            String base64 = Base64.getEncoder().encodeToString(imageBytes);

            String promptText = """
                    You are an expert image analyzer.
                    Describe the image clearly including:
                    - Objects
                    - People (if present)
                    - Colors
                    - Background
                    - Actions
                    
                    Here is the image (base64 encoded):
                    data:image/jpeg;base64,%s
                    """.formatted(base64);

            return chatClient.prompt()
                    .user(promptText)
                    .call()
                    .content();

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
