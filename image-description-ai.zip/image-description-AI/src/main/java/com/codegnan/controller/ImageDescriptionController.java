package com.codegnan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.codegnan.service.ImageDescriptionService;

@Controller
public class ImageDescriptionController {

    private final ImageDescriptionService imageService;

    public ImageDescriptionController(ImageDescriptionService imageService) {
        this.imageService = imageService;
    }

    @PostMapping("/describe")
    public String describe(@RequestParam("image") MultipartFile file, Model model) {

        if (file.isEmpty()) {
            model.addAttribute("description", "Please upload an image.");
            return "image-describer";
        }

        String result = imageService.describeImage(file);
        model.addAttribute("description", result);

        return "image-describer";
    }
}
